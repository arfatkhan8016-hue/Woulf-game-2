"""
FBX -> GLB converter (Blender 3.6 ya naya).

Use:
  blender --background --python tools/convert_models.py -- <folder_with_fbx> assets/models

Folder mein ye files honi chahiye:
  Punching.fbx           -> player.glb  (mesh + punch)
  Walking_Left_Turn.fbx  -> walk.glb    (walk animation)
  wolf.fbx               -> wolf.glb    (mesh + run/idle/fallen/sniffing)
"""
import bpy, sys, os

argv = sys.argv
argv = argv[argv.index("--") + 1:] if "--" in argv else []
if len(argv) < 2:
    print("Usage: blender -b -P convert_models.py -- <fbx_dir> <out_dir>")
    sys.exit(1)
src, dst = argv[0], argv[1]
os.makedirs(dst, exist_ok=True)

JOBS = [
    ("Punching.fbx", "player.glb", "Punching", True),
    ("Walking_Left_Turn.fbx", "walk.glb", "Walking", True),
    ("wolf.fbx", "wolf.glb", None, False),
]

def export_glb(path):
    kw = dict(filepath=path, export_format='GLB', export_skins=True, export_animations=True)
    try:
        bpy.ops.export_scene.gltf(export_animation_mode='ACTIONS', **kw)
    except TypeError:
        bpy.ops.export_scene.gltf(export_nla_strips=False, **kw)

def anim_len(a):
    # Blender 5 mein fcurves nahi hain, isliye frame_range se length nikalte hain
    try:
        fr = a.frame_range
        return float(fr[1] - fr[0])
    except Exception:
        try:
            return float(len(a.fcurves))
        except Exception:
            return 1.0

def locate(name):
    p = os.path.join(src, name)
    if os.path.exists(p):
        return p
    for root in (os.getcwd(), os.path.dirname(os.path.abspath(src))):
        for dp, dn, fn in os.walk(root):
            for f in fn:
                if f.lower() == name.lower():
                    return os.path.join(dp, f)
    return None

missing = []
for fbx, glb, anim_name, single in JOBS:
    p = locate(fbx)
    if p is None:
        print("NOT FOUND:", fbx)
        missing.append(fbx)
        continue
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.import_scene.fbx(filepath=p)
    acts = [a for a in bpy.data.actions if anim_len(a) > 0.0]
    print("ACTIONS in", fbx, [(a.name, anim_len(a)) for a in bpy.data.actions])
    if single:
        acts.sort(key=lambda a: -anim_len(a))
        for i, a in enumerate(acts):
            if i == 0:
                a.name = anim_name
            else:
                bpy.data.actions.remove(a)
    else:
        for a in acts:
            a.name = a.name.split('|')[-1]   # wolf_rig|running -> running
    out = os.path.join(dst, glb)
    export_glb(out)
    print("OK:", out, [a.name for a in bpy.data.actions])

for _, glb, _, _ in JOBS:
    if not os.path.exists(os.path.join(dst, glb)):
        print("ERROR: not created:", glb)
        sys.exit(1)
print("ALL MODELS CONVERTED")
