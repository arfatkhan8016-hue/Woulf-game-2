package com.fightgame

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.VertexAttributes.Usage
import com.badlogic.gdx.graphics.g3d.Material
import com.badlogic.gdx.graphics.g3d.Model
import com.badlogic.gdx.graphics.g3d.ModelInstance
import com.badlogic.gdx.graphics.g3d.model.Animation
import com.badlogic.gdx.graphics.g3d.model.Node
import com.badlogic.gdx.graphics.g3d.utils.AnimationController
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder
import com.badlogic.gdx.math.Vector3
import com.badlogic.gdx.math.collision.BoundingBox
import net.mgsx.gltf.loaders.glb.GLBLoader
import net.mgsx.gltf.scene3d.attributes.PBRColorAttribute
import net.mgsx.gltf.scene3d.attributes.PBRFloatAttribute
import net.mgsx.gltf.scene3d.scene.Scene
import net.mgsx.gltf.scene3d.scene.SceneAsset

object Models {
    val errors = ArrayList<String>()

    fun load(path: String): SceneAsset? {
        val fh = Gdx.files.internal(path)
        if (!fh.exists()) {
            Gdx.app.error("Models", "Missing file: $path")
            errors.add("Missing: $path")
            return null
        }
        return try {
            GLBLoader().load(fh)
        } catch (e: Throwable) {
            Gdx.app.error("Models", "Failed to load $path: $e")
            errors.add("Load failed: $path (${e.javaClass.simpleName})")
            null
        }
    }

    /** Animation ka id jisme `key` aata ho (case-insensitive). */
    fun anim(inst: ModelInstance, key: String): String? {
        for (a in inst.animations) if (a.id != null && a.id.contains(key, ignoreCase = true)) return a.id
        return null
    }

    private fun find(n: Node, key: String): Node? {
        val id = n.id ?: ""
        if (id.endsWith(key, ignoreCase = true)) return n
        for (c in n.children) {
            val r = find(c, key)
            if (r != null) return r
        }
        return null
    }

    fun node(inst: ModelInstance, key: String): Node? {
        for (n in inst.nodes) {
            val r = find(n, key)
            if (r != null) return r
        }
        return null
    }
}

/** Ek 3D character: scene + animation controller + auto size/foot fit. */
class Actor3D(val scene: Scene, targetHeight: Float, private val yawOffset: Float) {
    val inst: ModelInstance = scene.modelInstance
    val ctrl = AnimationController(inst)
    private val scale: Float
    private val yOff: Float
    private var current: String? = null
    private var curLoop = 0

    init {
        ctrl.allowSameAnimation = true
        val bb = BoundingBox()
        inst.calculateBoundingBox(bb)
        val h = bb.height
        if (h > 1e-4f && h < 1e5f) {
            scale = targetHeight / h
            yOff = -bb.min.y * scale
        } else {
            scale = 1f
            yOff = 0f
        }
        Gdx.app.log("Actor3D", "bbox height=$h -> scale=$scale")
    }

    fun place(x: Float, y: Float, z: Float, yawDeg: Float, sy: Float = 1f, pitchDeg: Float = 0f) {
        inst.transform.idt()
            .translate(x, y + yOff, z)
            .rotate(Vector3.Y, yawDeg + yawOffset)
            .rotate(Vector3.X, pitchDeg)
            .scale(scale, scale * sy, scale)
    }

    fun play(id: String?, loop: Int, speed: Float, trans: Float = 0.2f) {
        if (id == null) return
        if (current == id && curLoop == loop && loop < 0) {
            ctrl.current?.speed = speed
            return
        }
        ctrl.animate(id, loop, speed, null, trans)
        current = id
        curLoop = loop
    }

    fun duration(id: String?): Float {
        if (id == null) return 0f
        val a = inst.getAnimation(id) ?: return 0f
        return a.duration
    }

    fun update(dt: Float) {
        ctrl.update(dt)
    }

    fun nodeWorld(n: Node, out: Vector3): Vector3 =
        out.set(0f, 0f, 0f).mul(n.globalTransform).mul(inst.transform)
}

/** GLB ek baar load hota hai, phir bohot saare Actor3D bante hain (wolves). */
class ActorFactory(
    path: String,
    private val height: Float,
    private val yawOff: Float,
    private val color: Color,
    extraAnimFiles: List<String>
) {
    private val asset: SceneAsset? = Models.load(path)
    private val extra = ArrayList<Animation>()
    private var placeholder: Model? = null
    val missing: Boolean get() = asset == null

    init {
        for (f in extraAnimFiles) {
            val a = Models.load(f)
            if (a != null) {
                for (an in a.scene.model.animations) extra.add(an)
            }
        }
    }

    fun create(): Actor3D {
        val scene: Scene = if (asset != null) {
            Scene(asset.scene)
        } else {
            if (placeholder == null) {
                val mat = Material(
                    PBRColorAttribute.createBaseColorFactor(color),
                    PBRFloatAttribute.createMetallic(0f),
                    PBRFloatAttribute.createRoughness(0.6f)
                )
                placeholder = ModelBuilder().createCapsule(
                    height * 0.18f, height, 12, mat,
                    (Usage.Position or Usage.Normal).toLong()
                )
            }
            Scene(placeholder)
        }
        val a = Actor3D(scene, height, yawOff)
        for (an in extra) a.inst.copyAnimation(an, true)
        return a
    }
}
