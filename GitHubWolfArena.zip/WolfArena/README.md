# Wolf Arena (Kotlin + libGDX, 3D)

Wolves se bhari arena mein 3D fighter. Punch, walk animation, PBR lighting, real-time shadows,
blood spray / mist / splats / pools, hit-stop, camera shake, wave system.

## Kaise chalayen

### 1) FBX -> GLB (sirf ek baar)
Android par FBX seedha load nahi hota. Blender 3.6+ install karein, phir:

    blender --background --python tools/convert_models.py -- C:\apni_fbx_folder assets/models

(Windows: `tools\convert.bat C:\apni_fbx_folder`, Linux/Mac: `./tools/convert.sh /apni_fbx_folder`)

Folder mein `Punching.fbx`, `Walking_Left_Turn.fbx`, `wolf.fbx` hon.
Output: `assets/models/player.glb`, `walk.glb`, `wolf.glb`.

> Mixamo se download karte waqt **"In Place" tick karein**, warna character animation ke saath aage chal dega.

### 2) Android Studio
`WolfArena` folder open karein (Android Studio Hedgehog+, JDK 17), phone connect karke Run dabayein.
PC par test: `./gradlew :desktop:run` (WASD, SPACE/J = punch, SHIFT/K = dash).

Agar GLB files nahi hongi to game capsule placeholders ke saath chalega aur upar yellow warning dikhayega.

## Controls (phone)
- Left side drag: movement (floating joystick)
- PUNCH (bada laal button): auto-aim + lunge, asli haath ki bone speed se hit detect hota hai
- DASH (neela): i-frames ke saath tez side-step

## Tuning: `core/.../Config.kt`
- Character galat taraf dekh raha ho -> `PLAYER_YAW_OFFSET` / `WOLF_YAW_OFFSET` = 90, 180 ya -90
- Size -> `PLAYER_HEIGHT`, `WOLF_HEIGHT` (auto-fit hota hai)
- Hit nahi lag raha / zyada lag raha -> `HAND_HIT_RADIUS`, `HAND_MIN_SPEED`
- Walk speed vs pair sliding -> `WALK_ANIM_SPEED`

## Survival_Character.fbx
Iska skeleton alag hai (160 bones, `pelvis/spine_01...`) aur Mixamo animations seedhe nahi lagte.
Player ke liye isko use karna ho to Mixamo par is character ko upload karke auto-rig karein,
phir wahi Punching/Walking us rig par download karein aur converter mein file ka naam badal dein.
Dhyan rahe: 160 bones mobile ke liye bhari hain (SceneManager(128) limit badhani paregi).

## Note
Code is sandbox mein compile/test nahi ho saka (internet aur Blender nahi tha). Agar libGDX/gdx-gltf
ke kisi call par compile error aaye to error ki line bhej dein, turant theek kar dunga.

## Online APK (GitHub Actions) - Blender/Android Studio ki zaroorat nahi
1. GitHub par naya repo banayein, is folder ki saari files (fbx/, .github/ samet) upload karein.
2. Repo ke **Actions** tab mein "Build APK" run hone dein (5-10 min).
3. Run khulne par neeche **Artifacts -> WolfArena-apk** download karein, zip kholein, apk phone mein install karein.
