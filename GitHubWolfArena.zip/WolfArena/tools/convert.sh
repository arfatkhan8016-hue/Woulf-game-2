#!/bin/sh
# ./tools/convert.sh /path/to/fbx_folder
blender --background --python tools/convert_models.py -- "$1" assets/models
