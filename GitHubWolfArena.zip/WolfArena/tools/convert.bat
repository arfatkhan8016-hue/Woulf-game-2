@echo off
REM tools\convert.bat C:\path\to\fbx_folder
"C:\Program Files\Blender Foundation\Blender 4.2\blender.exe" --background --python tools\convert_models.py -- %1 assets\models
