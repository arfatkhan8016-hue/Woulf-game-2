"""
FBX -> GLB converter (Blender 3.6 ya naya).

Use:
  blender --background --python tools/convert_models.py -- <folder_with_fbx> assets/models

Folder mein ye files honi chahiye:
  Punching.fbx           -> player.glb  (mesh + punch)
  Walking_Left_Turn.fbx  -> walk.glb    (walk animation)
  wolf.fbx               -> wolf.glb    (mesh + run/idle/fallen/sniffing)
"""
import bpy, sys, os

argv = sys.argv
argv = argv[argv.index("--") + 1:] if "--" in argv else []
if len(argv) < 2:
    print("Usage: blender -b -P convert_models.py -- <fbx_dir> <out_dir>")
    sys.exit(1)
src, dst = argv[0], argv[1]
os.makedirs(dst, exist_ok=True)

JOBS = [
    ("Punching.fbx", "player.glb", "Punching", True),
    ("Walking_Left_Turn.fbx", "walk.glb", "Walking", True),
    ("wolf.fbx", "wolf.glb", None, False),
]

def export_glb(path):
    kw = dict(filepath=path, export_format='GLB', export_skins=True, export_animations=True)
    try:
        bpy.ops.export_scene.gltf(export_animation_mode='ACTIONS', **kw)
    except TypeError:
        bpy.ops.export_scene.gltf(export_nla_strips=False, **kw)

for fbx, glb, anim_name, single in JOBS:
    p = os.path.join(src, fbx)
    if not os.path.exists(p):
        print("SKIP (not found):", p)
        continue
    bpy.ops.wm.read_factory_settings(use_empty=True)
    bpy.ops.import_scene.fbx(filepath=p)
    acts = [a for a in bpy.data.actions if len(a.fcurves) > 0]
    if single:
        acts.sort(key=lambda a: -len(a.fcurves))
        for i, a in enumerate(acts):
            if i == 0:
                a.name = anim_name
            else:
                bpy.data.actions.remove(a)
    else:
        for a in acts:
            a.name = a.name.split('|')[-1]   # wolf_rig|running -> running
    out = os.path.join(dst, glb)
    export_glb(out)
    print("OK:", out, [a.name for a in bpy.data.actions])
