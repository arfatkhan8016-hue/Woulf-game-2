package com.fightgame.desktop

import com.badlogic.gdx.backends.lwjgl3.Lwjgl3Application
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3ApplicationConfiguration
import com.fightgame.FightGame

fun main() {
    val cfg = Lwjgl3ApplicationConfiguration()
    cfg.setTitle("Wolf Arena")
    cfg.setWindowedMode(1280, 720)
    cfg.useVsync(true)
    cfg.setForegroundFPS(60)
    cfg.setBackBufferConfig(8, 8, 8, 8, 24, 0, 4)
    Lwjgl3Application(FightGame(), cfg)
}
