package com.fightgame

import com.badlogic.gdx.math.MathUtils
import kotlin.math.atan2
import kotlin.math.sqrt

class Wolf(
    val actor: Actor3D, var x: Float, var z: Float,
    val hpMax: Float, private val speed: Float, val dmg: Float
) {
    enum class S { CHASE, WINDUP, LUNGE, RECOVER, HURT, DEAD }

    var state = S.CHASE
    var hp = hpMax
    var yaw = 0f
    var hitCd = 0f
    var deadT = 0f
    val dead: Boolean get() = state == S.DEAD

    private var t = 0f
    private var kx = 0f
    private var kz = 0f
    private var lx = 0f
    private var lz = 0f
    private var cooldown = 0.8f + Math.random().toFloat()
    private var dealt = false

    private val aRun = Models.anim(actor.inst, "run")
    private val aIdle = Models.anim(actor.inst, "idle")
    private val aSniff = Models.anim(actor.inst, "sniff")
    private val aFallen = Models.anim(actor.inst, "fallen")

    init {
        actor.play(aRun ?: aIdle, -1, 1f, 0f)
    }

    /** true = wolf mar gaya */
    fun takeHit(dmg: Float, nx: Float, nz: Float): Boolean {
        hp -= dmg
        hitCd = 0.3f
        if (hp <= 0f) {
            state = S.DEAD
            deadT = 0f
            kx = nx * 3.5f
            kz = nz * 3.5f
            actor.play(aFallen ?: aIdle, 1, 1.1f, 0.1f)
            return true
        }
        state = S.HURT
        t = 0f
        kx = nx * 6f
        kz = nz * 6f
        return false
    }

    fun update(dt: Float, p: Player, others: List<Wolf>, bite: (Wolf) -> Unit) {
        t += dt
        if (hitCd > 0f) hitCd -= dt
        val dx = p.x - x
        val dz = p.z - z
        val dist = sqrt(dx * dx + dz * dz).coerceAtLeast(0.001f)
        val nx = dx / dist
        val nz = dz / dist
        val face = atan2(nx, nz) * MathUtils.radiansToDegrees

        when (state) {
            S.CHASE -> {
                yaw = approachAngle(yaw, face, 540f * dt)
                val sp = if (dist > 2.0f) speed else speed * 0.3f
                x += nx * sp * dt
                z += nz * sp * dt
                actor.play(aRun ?: aIdle, -1, 0.8f + speed * 0.12f)
                cooldown -= dt
                if (dist < 2.4f && cooldown <= 0f && !p.isDead) {
                    state = S.WINDUP; t = 0f
                }
            }
            S.WINDUP -> {
                yaw = approachAngle(yaw, face, 720f * dt)
                actor.play(aSniff ?: aIdle, -1, 1.6f)
                if (t > 0.38f) {
                    state = S.LUNGE; t = 0f; dealt = false
                    lx = nx; lz = nz
                }
            }
            S.LUNGE -> {
                x += lx * 10.5f * dt
                z += lz * 10.5f * dt
                actor.play(aRun ?: aIdle, -1, 2.0f)
                if (!dealt && dist < 1.2f) { dealt = true; bite(this) }
                if (t > 0.32f) { state = S.RECOVER; t = 0f; cooldown = 1.1f }
            }
            S.RECOVER -> {
                actor.play(aIdle ?: aRun, -1, 1f)
                if (t > 0.6f) state = S.CHASE
            }
            S.HURT -> {
                x += kx * dt; z += kz * dt
                kx *= 0.88f; kz *= 0.88f
                if (t > 0.28f) state = S.CHASE
            }
            S.DEAD -> {
                deadT += dt
                x += kx * dt; z += kz * dt
                kx *= 0.9f; kz *= 0.9f
            }
        }

        if (!dead) {
            for (o in others) {
                if (o === this || o.dead) continue
                val ox = x - o.x
                val oz = z - o.z
                val d = sqrt(ox * ox + oz * oz)
                if (d < 0.9f && d > 0.0001f) {
                    val push = (0.9f - d) * 0.5f
                    x += ox / d * push
                    z += oz / d * push
                }
            }
        }
        val rr = sqrt(x * x + z * z)
        val lim = Config.ARENA_RADIUS - 0.5f
        if (rr > lim) { x *= lim / rr; z *= lim / rr }

        actor.update(dt)
        actor.place(x, 0f, z, yaw)
    }
}
