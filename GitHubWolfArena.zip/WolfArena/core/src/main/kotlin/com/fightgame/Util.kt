package com.fightgame

import kotlin.math.abs

/** current angle (degrees) ko target ki taraf maxStep tak ghumao (shortest path). */
fun approachAngle(cur: Float, target: Float, maxStep: Float): Float {
    var d = ((target - cur + 540f) % 360f) - 180f
    if (d > maxStep) d = maxStep
    if (d < -maxStep) d = -maxStep
    var r = cur + d
    if (r > 180f) r -= 360f
    if (r < -180f) r += 360f
    return r
}

fun angleDiff(a: Float, b: Float): Float = abs(((a - b + 540f) % 360f) - 180f)
