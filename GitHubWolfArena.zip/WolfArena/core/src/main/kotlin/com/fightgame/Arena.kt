package com.fightgame

import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.Pixmap
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.VertexAttributes.Usage
import com.badlogic.gdx.graphics.g3d.Material
import com.badlogic.gdx.graphics.g3d.Model
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute
import com.badlogic.gdx.graphics.g3d.attributes.IntAttribute
import com.badlogic.gdx.graphics.g3d.utils.ModelBuilder
import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.math.Vector3
import com.badlogic.gdx.utils.Disposable
import net.mgsx.gltf.scene3d.attributes.PBRColorAttribute
import net.mgsx.gltf.scene3d.attributes.PBRFloatAttribute
import net.mgsx.gltf.scene3d.attributes.PBRTextureAttribute
import net.mgsx.gltf.scene3d.lights.PointLightEx
import net.mgsx.gltf.scene3d.scene.Scene
import net.mgsx.gltf.scene3d.scene.SceneManager

/** Pathar ka floor, gol deewar, pillars aur flicker karti mashaalein. */
class Arena(private val sm: SceneManager) : Disposable {
    private val models = ArrayList<Model>()
    private val textures = ArrayList<Texture>()
    private val torches = ArrayList<PointLightEx>()
    private var time = 0f

    private fun stoneTexture(): Texture {
        val n = 256
        val pm = Pixmap(n, n, Pixmap.Format.RGBA8888)
        val rnd = java.util.Random(7)
        val slab = n / 4
        val tone = FloatArray(16) { 0.85f + rnd.nextFloat() * 0.3f }
        for (y in 0 until n) for (x in 0 until n) {
            var v = 0.34f * tone[(y / slab) * 4 + (x / slab)]
            v += (rnd.nextFloat() - 0.5f) * 0.07f
            if (x % slab < 2 || y % slab < 2) v *= 0.45f
            pm.drawPixel(x, y, Color.rgba8888(v, v * 0.97f, v * 0.92f, 1f))
        }
        val t = Texture(pm, Pixmap.Format.RGBA8888, true)
        t.setFilter(Texture.TextureFilter.MipMapLinearLinear, Texture.TextureFilter.Linear)
        t.setWrap(Texture.TextureWrap.Repeat, Texture.TextureWrap.Repeat)
        pm.dispose()
        return t
    }

    init {
        val attrs = (Usage.Position or Usage.Normal or Usage.TextureCoordinates).toLong()
        val tex = stoneTexture()
        textures.add(tex)

        fun stoneMat(rough: Float, tint: Color): Material = Material(
            PBRTextureAttribute(PBRTextureAttribute.BaseColorTexture, tex),
            PBRColorAttribute.createBaseColorFactor(tint),
            PBRFloatAttribute.createMetallic(0f),
            PBRFloatAttribute.createRoughness(rough),
            IntAttribute.createCullFace(GL20.GL_NONE)
        )

        val mb = ModelBuilder()

        // Floor (texture 14x14 baar tile hota hai)
        mb.begin()
        val part = mb.part("floor", GL20.GL_TRIANGLES, attrs, stoneMat(0.9f, Color(0.85f, 0.85f, 0.9f, 1f)))
        part.setUVRange(0f, 0f, 14f, 14f)
        val s = 60f
        part.rect(-s, 0f, s, s, 0f, s, s, 0f, -s, -s, 0f, -s, 0f, 1f, 0f)
        val floor = mb.end()
        models.add(floor)
        sm.addScene(Scene(floor))

        // Deewar
        val wall = mb.createBox(4.8f, 4.5f, 1.4f, stoneMat(0.95f, Color(0.7f, 0.7f, 0.75f, 1f)), attrs)
        models.add(wall)
        val wallR = Config.ARENA_RADIUS + 1.6f
        val n = 30
        for (i in 0 until n) {
            val a = 360f * i / n
            val sc = Scene(wall)
            sc.modelInstance.transform.idt()
                .translate(MathUtils.sinDeg(a) * wallR, 2.25f, MathUtils.cosDeg(a) * wallR)
                .rotate(Vector3.Y, a)
            sm.addScene(sc)
        }

        // Pillars + mashaalein
        val pillar = mb.createCylinder(1.5f, 6.2f, 1.5f, 14, stoneMat(0.8f, Color(0.9f, 0.9f, 0.95f, 1f)), attrs)
        models.add(pillar)
        val flameMat = Material(
            PBRColorAttribute.createBaseColorFactor(Color(1f, 0.55f, 0.1f, 1f)),
            ColorAttribute.createEmissive(Color(3f, 1.4f, 0.3f, 1f))
        )
        val flame = mb.createBox(0.34f, 0.5f, 0.34f, flameMat, (Usage.Position or Usage.Normal).toLong())
        models.add(flame)
        for (i in 0 until 4) {
            val a = 45f + 90f * i
            val px = MathUtils.sinDeg(a) * (wallR - 1.2f)
            val pz = MathUtils.cosDeg(a) * (wallR - 1.2f)
            val p = Scene(pillar)
            p.modelInstance.transform.idt().translate(px, 3.1f, pz)
            sm.addScene(p)
            val tx = MathUtils.sinDeg(a) * (wallR - 2.15f)
            val tz = MathUtils.cosDeg(a) * (wallR - 2.15f)
            val f = Scene(flame)
            f.modelInstance.transform.idt().translate(tx, 3.1f, tz)
            sm.addScene(f)
            val light = PointLightEx()
            light.set(Color(1f, 0.5f, 0.18f, 1f), Vector3(tx, 3.4f, tz), 18f)
            sm.environment.add(light)
            torches.add(light)
        }
    }

    fun update(dt: Float) {
        time += dt
        for ((i, l) in torches.withIndex()) {
            val f = 0.8f + 0.12f * MathUtils.sin(time * 11f + i * 2f) + 0.08f * MathUtils.sin(time * 27f + i * 5f)
            l.intensity = 18f * f
        }
    }

    override fun dispose() {
        for (m in models) m.dispose()
        for (t in textures) t.dispose()
    }
}
