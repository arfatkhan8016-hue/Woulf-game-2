package com.fightgame

/** Saari tuning yahin se hoti hai. */
object Config {
    // assets/ folder ke andar (convert_models.py yeh files banata hai)
    const val PLAYER_MODEL = "models/player.glb"      // Punching.fbx -> mesh + punch animation
    const val WALK_ANIM_FILE = "models/walk.glb"      // Walking_Left_Turn.fbx -> walk animation
    const val WOLF_MODEL = "models/wolf.glb"          // wolf.fbx -> mesh + run/idle/fallen/sniff

    const val PLAYER_HEIGHT = 1.8f
    const val WOLF_HEIGHT = 1.0f
    // Agar model ulta/side ki taraf dekh raha ho to yeh degrees badlo (0, 90, 180, -90)
    const val PLAYER_YAW_OFFSET = 0f
    const val WOLF_YAW_OFFSET = 0f

    const val ARENA_RADIUS = 17f
    const val PLAYER_SPEED = 4.2f
    const val WALK_ANIM_SPEED = 1.9f
    const val PUNCH_ANIM_SPEED = 1.5f
    const val PUNCH_MAX_TIME = 1.6f
    const val PUNCH_DAMAGE = 16f
    const val DASH_SPEED = 11f
    const val DASH_TIME = 0.28f
    const val HAND_HIT_RADIUS = 0.85f
    const val HAND_MIN_SPEED = 1.8f
}
