package com.fightgame

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.Input
import com.badlogic.gdx.InputAdapter
import kotlin.math.sqrt

/** Touch (joystick + buttons) aur keyboard (WASD, SPACE/J = punch, SHIFT/K = dash, R = restart). */
class Controls : InputAdapter() {
    var w = 1280
    var h = 720
    var r = 90f

    var mx = 0f
    var my = 0f

    var joyId = -1
    var jcx = 0f
    var jcy = 0f
    var jx = 0f
    var jy = 0f
    val joyActive: Boolean get() = joyId != -1

    var punchId = -1
    var dashId = -1
    var punchX = 0f
    var punchY = 0f
    var punchR = 0f
    var dashX = 0f
    var dashY = 0f
    var dashR = 0f

    var punchQueued = false
    var dashQueued = false
    var tapQueued = false

    fun resize(width: Int, height: Int) {
        w = width
        h = height
        r = height * 0.12f
        punchX = w - r * 1.9f
        punchY = r * 2.0f
        punchR = r * 1.05f
        dashX = w - r * 4.4f
        dashY = r * 1.3f
        dashR = r * 0.75f
    }

    private fun inside(x: Float, y: Float, cx: Float, cy: Float, rad: Float): Boolean {
        val dx = x - cx
        val dy = y - cy
        return dx * dx + dy * dy <= rad * rad
    }

    override fun touchDown(screenX: Int, screenY: Int, pointer: Int, button: Int): Boolean {
        val x = screenX.toFloat()
        val y = h - screenY.toFloat()
        tapQueued = true
        if (inside(x, y, punchX, punchY, punchR * 1.25f)) {
            punchId = pointer
            punchQueued = true
        } else if (inside(x, y, dashX, dashY, dashR * 1.3f)) {
            dashId = pointer
            dashQueued = true
        } else if (x < w * 0.5f && joyId == -1) {
            joyId = pointer
            jcx = x
            jcy = y
            jx = 0f
            jy = 0f
        }
        return true
    }

    override fun touchDragged(screenX: Int, screenY: Int, pointer: Int): Boolean {
        if (pointer == joyId) {
            val x = screenX.toFloat()
            val y = h - screenY.toFloat()
            val rad = r * 1.3f
            var dx = (x - jcx) / rad
            var dy = (y - jcy) / rad
            val l = sqrt(dx * dx + dy * dy)
            if (l > 1f) { dx /= l; dy /= l }
            if (l < 0.12f) { dx = 0f; dy = 0f }
            jx = dx
            jy = dy
        }
        return true
    }

    override fun touchUp(screenX: Int, screenY: Int, pointer: Int, button: Int): Boolean {
        if (pointer == joyId) { joyId = -1; jx = 0f; jy = 0f }
        if (pointer == punchId) punchId = -1
        if (pointer == dashId) dashId = -1
        return true
    }

    override fun keyDown(keycode: Int): Boolean {
        when (keycode) {
            Input.Keys.SPACE, Input.Keys.J -> punchQueued = true
            Input.Keys.SHIFT_LEFT, Input.Keys.K -> dashQueued = true
            Input.Keys.R, Input.Keys.ENTER -> tapQueued = true
        }
        return true
    }

    fun poll() {
        val i = Gdx.input
        var kx = 0f
        var ky = 0f
        if (i.isKeyPressed(Input.Keys.A) || i.isKeyPressed(Input.Keys.LEFT)) kx -= 1f
        if (i.isKeyPressed(Input.Keys.D) || i.isKeyPressed(Input.Keys.RIGHT)) kx += 1f
        if (i.isKeyPressed(Input.Keys.W) || i.isKeyPressed(Input.Keys.UP)) ky += 1f
        if (i.isKeyPressed(Input.Keys.S) || i.isKeyPressed(Input.Keys.DOWN)) ky -= 1f
        mx = (jx + kx).coerceIn(-1f, 1f)
        my = (jy + ky).coerceIn(-1f, 1f)
        val l = sqrt(mx * mx + my * my)
        if (l > 1f) { mx /= l; my /= l }
    }

    fun endFrame() {
        punchQueued = false
        dashQueued = false
        tapQueued = false
    }
}
