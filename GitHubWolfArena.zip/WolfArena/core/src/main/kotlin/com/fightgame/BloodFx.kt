package com.fightgame

import com.badlogic.gdx.Gdx
import com.badlogic.gdx.graphics.Camera
import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.Pixmap
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.g2d.TextureRegion
import com.badlogic.gdx.graphics.g3d.decals.CameraGroupStrategy
import com.badlogic.gdx.graphics.g3d.decals.Decal
import com.badlogic.gdx.graphics.g3d.decals.DecalBatch
import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.math.Vector3
import com.badlogic.gdx.utils.Disposable
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import com.badlogic.gdx.utils.Array as GdxArray

/** Transparent decals: depth write band, taaki soft edges dusre decals ko na kaatein. */
private class NoDepthWriteStrategy(cam: Camera) : CameraGroupStrategy(cam) {
    override fun beforeGroup(group: Int, contents: GdxArray<Decal>?) {
        super.beforeGroup(group, contents)
        Gdx.gl.glDepthMask(false)
    }

    override fun afterGroup(group: Int) {
        super.afterGroup(group)
        Gdx.gl.glDepthMask(true)
    }
}

/** Khoon ka poora system: 3D droplets, mist, zameen par splats aur pools. */
class BloodFx(private val cam: Camera) : Disposable {
    private class P(
        val d: Decal, var vx: Float, var vy: Float, var vz: Float,
        var life: Float, val maxLife: Float, val mist: Boolean, val size: Float
    )

    private class Floor(val d: Decal, var age: Float, val maxSize: Float, val grows: Boolean, val startAlpha: Float)

    private val rnd = java.util.Random()
    private val batch = DecalBatch(1500, NoDepthWriteStrategy(cam))
    private val textures = ArrayList<Texture>()
    private val splats = ArrayList<TextureRegion>()
    private val dropTex: TextureRegion
    private val mistTex: TextureRegion
    private val drops = ArrayList<P>()
    private val floors = ArrayList<Floor>()
    private val up = Vector3()
    private var layer = 0

    init {
        for (i in 0 until 4) splats.add(makeSplat(128, 100L + i * 17, 7 + i))
        dropTex = makeRound(32, 0.9f)
        mistTex = makeRound(64, 0.35f)
    }

    private fun reg(pm: Pixmap): TextureRegion {
        val t = Texture(pm)
        t.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear)
        pm.dispose()
        textures.add(t)
        return TextureRegion(t)
    }

    private fun makeRound(size: Int, hardness: Float): TextureRegion {
        val pm = Pixmap(size, size, Pixmap.Format.RGBA8888)
        pm.blending = Pixmap.Blending.None
        for (y in 0 until size) for (x in 0 until size) {
            val nx = (x + 0.5f) / size * 2f - 1f
            val ny = (y + 0.5f) / size * 2f - 1f
            val d = sqrt(nx * nx + ny * ny)
            var a = (1f - d).coerceIn(0f, 1f)
            a = min(1f, a / (1f - hardness + 0.001f) * 0.6f).coerceIn(0f, 1f)
            pm.drawPixel(x, y, Color.rgba8888(0.62f, 0.02f, 0.03f, a))
        }
        return reg(pm)
    }

    private fun makeSplat(size: Int, seed: Long, arms: Int): TextureRegion {
        val r = java.util.Random(seed)
        val blobs = ArrayList<FloatArray>()
        blobs.add(floatArrayOf(0f, 0f, 0.34f))
        for (i in 0 until arms) {
            val a = r.nextFloat() * MathUtils.PI2
            val d = 0.22f + r.nextFloat() * 0.45f
            val rad = 0.04f + r.nextFloat() * 0.11f
            blobs.add(floatArrayOf(MathUtils.cos(a) * d, MathUtils.sin(a) * d, rad))
            for (s in 1..3) {
                val dd = d * (0.35f + 0.22f * s)
                blobs.add(floatArrayOf(MathUtils.cos(a) * dd, MathUtils.sin(a) * dd, rad * (0.7f - 0.15f * s).coerceAtLeast(0.15f)))
            }
            val far = d + 0.18f + r.nextFloat() * 0.2f
            if (far < 0.95f) blobs.add(floatArrayOf(MathUtils.cos(a) * far, MathUtils.sin(a) * far, 0.025f + r.nextFloat() * 0.03f))
        }
        val pm = Pixmap(size, size, Pixmap.Format.RGBA8888)
        pm.blending = Pixmap.Blending.None
        for (y in 0 until size) for (x in 0 until size) {
            val nx = (x + 0.5f) / size * 2f - 1f
            val ny = (y + 0.5f) / size * 2f - 1f
            var v = 0f
            for (b in blobs) {
                val dx = nx - b[0]
                val dy = ny - b[1]
                val t = 1f - sqrt(dx * dx + dy * dy) / b[2]
                if (t > v) v = t
            }
            val a = (v * 3f).coerceIn(0f, 1f)
            val shade = 0.30f + 0.32f * v.coerceIn(0f, 1f)
            pm.drawPixel(x, y, Color.rgba8888(shade, 0.0f, 0.012f, a))
        }
        return reg(pm)
    }

    private fun flat(d: Decal) {
        val a = rnd.nextFloat() * MathUtils.PI2
        d.setRotation(Vector3.Y, up.set(MathUtils.cos(a), 0f, MathUtils.sin(a)))
    }

    /** Zameen par ek splat. */
    fun floorSplat(x: Float, z: Float, size: Float) {
        val d = Decal.newDecal(1f, 1f, splats[rnd.nextInt(splats.size)], true)
        layer = (layer + 1) % 200
        d.setPosition(x, 0.015f + layer * 0.0003f, z)
        flat(d)
        d.setScale(size)
        d.setColor(1f, 1f, 1f, 0.95f)
        floors.add(Floor(d, 0f, size, false, 0.95f))
        while (floors.size > 170) floors.removeAt(0)
    }

    /** Maray huay wolf ke neeche badhta hua khoon ka pool. */
    fun pool(x: Float, z: Float) {
        val d = Decal.newDecal(1f, 1f, splats[rnd.nextInt(splats.size)], true)
        layer = (layer + 1) % 200
        d.setPosition(x, 0.012f + layer * 0.0003f, z)
        flat(d)
        d.setScale(0.2f)
        d.setColor(1f, 1f, 1f, 0.97f)
        floors.add(Floor(d, 0f, 2.4f + rnd.nextFloat() * 0.8f, true, 0.97f))
        while (floors.size > 170) floors.removeAt(0)
    }

    /** Khoon ka fawwara: (dx,dz) = hit ki disha (normalized). */
    fun burst(x: Float, y: Float, z: Float, dx: Float, dz: Float, count: Int, power: Float) {
        if (drops.size > 420) return
        for (i in 0 until count) {
            val sp = power * (0.35f + rnd.nextFloat() * 0.95f)
            val vx = dx * sp + (rnd.nextFloat() - 0.5f) * power * 0.8f
            val vz = dz * sp + (rnd.nextFloat() - 0.5f) * power * 0.8f
            val vy = 1.2f + rnd.nextFloat() * power * 0.7f
            val size = 0.05f + rnd.nextFloat() * 0.12f
            val d = Decal.newDecal(size, size * (1.0f + rnd.nextFloat() * 0.8f), dropTex, true)
            d.setPosition(x, y, z)
            drops.add(P(d, vx, vy, vz, 1.4f, 1.4f, false, size))
        }
        val mistN = max(2, count / 7)
        for (i in 0 until mistN) {
            val d = Decal.newDecal(1f, 1f, mistTex, true)
            d.setPosition(
                x + (rnd.nextFloat() - 0.5f) * 0.3f,
                y + (rnd.nextFloat() - 0.5f) * 0.3f,
                z + (rnd.nextFloat() - 0.5f) * 0.3f
            )
            val s = 0.35f + rnd.nextFloat() * 0.5f
            d.setScale(s)
            drops.add(P(d, dx * 0.8f, 0.3f, dz * 0.8f, 0.55f, 0.55f, true, s))
        }
        floorSplat(x + dx * (0.6f + rnd.nextFloat()), z + dz * (0.6f + rnd.nextFloat()), 0.5f + rnd.nextFloat() * 0.5f)
    }

    fun update(dt: Float) {
        val it = drops.iterator()
        while (it.hasNext()) {
            val p = it.next()
            p.life -= dt
            if (p.life <= 0f) { it.remove(); continue }
            val pos = p.d.position
            if (p.mist) {
                pos.add(p.vx * dt, p.vy * dt, p.vz * dt)
                val k = 1f - p.life / p.maxLife
                p.d.setScale(p.size * (1f + k * 1.8f))
                p.d.setColor(1f, 1f, 1f, 0.55f * (1f - k))
            } else {
                p.vy -= 14f * dt
                pos.add(p.vx * dt, p.vy * dt, p.vz * dt)
                if (pos.y <= 0.03f) {
                    if (rnd.nextFloat() < 0.55f) floorSplat(pos.x, pos.z, p.size * (2.5f + rnd.nextFloat() * 3f))
                    it.remove()
                    continue
                }
                p.d.setColor(1f, 1f, 1f, min(1f, p.life * 2f))
            }
            p.d.lookAt(cam.position, cam.up)
        }
        for (f in floors) {
            f.age += dt
            if (f.grows) {
                val k = min(1f, f.age / 5f)
                f.d.setScale(0.2f + (f.maxSize - 0.2f) * sqrt(k))
            }
        }
    }

    fun render() {
        for (f in floors) batch.add(f.d)
        for (p in drops) batch.add(p.d)
        batch.flush()
    }

    fun clear() {
        drops.clear()
        floors.clear()
    }

    override fun dispose() {
        batch.dispose()
        for (t in textures) t.dispose()
    }
}
