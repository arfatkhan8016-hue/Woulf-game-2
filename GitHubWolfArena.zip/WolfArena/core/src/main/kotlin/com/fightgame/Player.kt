package com.fightgame

import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.math.Vector3
import kotlin.math.atan2
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

class Player(val actor: Actor3D) {
    enum class S { IDLE, WALK, PUNCH, DASH, HURT, DEAD }

    var x = 0f
    var z = 0f
    var yaw = 0f
    val maxHp = 100f
    var hp = maxHp
    var state = S.IDLE
    val isDead: Boolean get() = state == S.DEAD

    private var t = 0f
    private var clock = 0f
    private var invuln = 0f
    private var dashCd = 0f
    private var fallT = 0f
    private var dashX = 0f
    private var dashZ = 0f
    private var kx = 0f
    private var kz = 0f
    private var punchTime = 1f
    private var punchLunge = 0f
    private val rnd = java.util.Random()

    private val aPunch = Models.anim(actor.inst, "punch")
    private val aWalk = Models.anim(actor.inst, "walk")
    private val handR = Models.node(actor.inst, "RightHand")
    private val handL = Models.node(actor.inst, "LeftHand")
    private val pR = Vector3()
    private val pL = Vector3()
    private val cR = Vector3()
    private val cL = Vector3()
    private var havePrev = false

    init {
        com.badlogic.gdx.Gdx.app.log(
            "Player",
            "anims: punch=$aPunch walk=$aWalk handR=${handR?.id} handL=${handL?.id}"
        )
    }

    fun reset() {
        x = 0f; z = 0f; yaw = 0f
        hp = maxHp
        state = S.IDLE
        t = 0f; invuln = 0f; fallT = 0f; dashCd = 0f
    }

    fun hurt(dmg: Float, dx: Float, dz: Float): Boolean {
        if (invuln > 0f || isDead) return false
        hp -= dmg
        invuln = 0.6f
        kx = dx * 5f
        kz = dz * 5f
        if (hp <= 0f) {
            hp = 0f
            state = S.DEAD
            fallT = 0f
        } else if (state != S.PUNCH) {
            state = S.HURT
            t = 0f
        }
        return true
    }

    fun update(
        dt: Float, mx: Float, mz: Float, wantPunch: Boolean, wantDash: Boolean,
        wolves: List<Wolf>, onHit: (Wolf, Float, Float, Float, Float) -> Unit
    ) {
        clock += dt
        if (invuln > 0f) invuln -= dt
        if (dashCd > 0f) dashCd -= dt
        val ml = sqrt(mx * mx + mz * mz)

        when (state) {
            S.DEAD -> fallT += dt
            S.HURT -> {
                t += dt
                x += kx * dt; z += kz * dt
                kx *= 0.9f; kz *= 0.9f
                if (t > 0.22f) state = S.IDLE
            }
            S.DASH -> {
                t += dt
                x += dashX * Config.DASH_SPEED * dt
                z += dashZ * Config.DASH_SPEED * dt
                actor.play(aWalk ?: aPunch, -1, 2.6f)
                if (t >= Config.DASH_TIME) state = S.IDLE
            }
            S.PUNCH -> {
                t += dt
                if (punchLunge > 0f && t < punchTime * 0.4f) {
                    val sp = punchLunge / (punchTime * 0.4f)
                    x += MathUtils.sinDeg(yaw) * sp * dt
                    z += MathUtils.cosDeg(yaw) * sp * dt
                }
                detectHits(dt, wolves, onHit)
                if (wantPunch && t > punchTime * 0.55f) startPunch(wolves)
                else if (t >= punchTime) state = S.IDLE
            }
            else -> {
                if (wantPunch) {
                    startPunch(wolves)
                } else if (wantDash && dashCd <= 0f) {
                    startDash(mx, mz, ml)
                } else if (ml > 0.12f) {
                    state = S.WALK
                    yaw = approachAngle(yaw, atan2(mx, mz) * MathUtils.radiansToDegrees, 900f * dt)
                    val sp = Config.PLAYER_SPEED * min(1f, ml)
                    x += mx / ml * sp * dt
                    z += mz / ml * sp * dt
                    actor.play(aWalk ?: aPunch, -1, Config.WALK_ANIM_SPEED * (0.6f + 0.4f * min(1f, ml)))
                } else {
                    state = S.IDLE
                    actor.play(aPunch, -1, 0f, 0.25f) // punch ka pehla frame = fighting stance
                }
            }
        }

        val dist = sqrt(x * x + z * z)
        val lim = Config.ARENA_RADIUS - 0.6f
        if (dist > lim) { x *= lim / dist; z *= lim / dist }

        actor.update(dt)
        val pitch = if (state == S.DEAD) -90f * min(1f, fallT / 0.5f) else 0f
        val breathe = if (state == S.IDLE) 1f + 0.006f * sin(clock * 2.2f) else 1f
        actor.place(x, if (state == S.DEAD) 0.12f else 0f, z, yaw, breathe, pitch)
    }

    private fun startPunch(wolves: List<Wolf>) {
        state = S.PUNCH
        t = 0f
        havePrev = false
        var best: Wolf? = null
        var bd = 36f
        for (w in wolves) {
            if (w.dead) continue
            val dx = w.x - x
            val dz = w.z - z
            val d = dx * dx + dz * dz
            if (d < bd) { bd = d; best = w }
        }
        if (best != null) {
            yaw = atan2(best.x - x, best.z - z) * MathUtils.radiansToDegrees // auto-aim
            punchLunge = (sqrt(bd) - 1.0f).coerceIn(0f, 2.2f)
        } else {
            punchLunge = 0f
        }
        val spd = Config.PUNCH_ANIM_SPEED
        punchTime = min(Config.PUNCH_MAX_TIME, actor.duration(aPunch) / spd)
        if (punchTime < 0.3f) punchTime = 0.6f
        actor.play(aPunch, 1, spd, 0.08f)
    }

    private fun startDash(mx: Float, mz: Float, ml: Float) {
        state = S.DASH
        t = 0f
        dashCd = 0.7f
        if (ml > 0.12f) { dashX = mx / ml; dashZ = mz / ml }
        else { dashX = MathUtils.sinDeg(yaw); dashZ = MathUtils.cosDeg(yaw) }
        yaw = atan2(dashX, dashZ) * MathUtils.radiansToDegrees
        invuln = Config.DASH_TIME + 0.12f
    }

    private fun near(h: Vector3, w: Wolf): Boolean {
        val dx = h.x - w.x
        val dz = h.z - w.z
        val rr = Config.HAND_HIT_RADIUS
        return dx * dx + dz * dz < rr * rr && h.y > 0.1f && h.y < 1.9f
    }

    /** Asli haath ki bone ki speed + position se hit detect hota hai. */
    private fun detectHits(dt: Float, wolves: List<Wolf>, onHit: (Wolf, Float, Float, Float, Float) -> Unit) {
        val hr = handR
        val hl = handL
        if (hr != null && hl != null) {
            actor.nodeWorld(hr, cR)
            actor.nodeWorld(hl, cL)
            if (havePrev && dt > 1e-5f) {
                val sr = cR.dst(pR) / dt
                val sl = cL.dst(pL) / dt
                for (w in wolves) {
                    if (w.dead || w.hitCd > 0f) continue
                    val useR = sr > Config.HAND_MIN_SPEED && near(cR, w)
                    val useL = sl > Config.HAND_MIN_SPEED && near(cL, w)
                    if (useR || useL) {
                        val h = if (useR && (!useL || sr >= sl)) cR else cL
                        w.hitCd = 0.35f
                        onHit(w, Config.PUNCH_DAMAGE * (0.9f + 0.2f * rnd.nextFloat()), h.x, h.y, h.z)
                    }
                }
            }
            pR.set(cR)
            pL.set(cL)
            havePrev = true
        } else {
            // Fallback: hand bones na milein to timing se hit
            val k = t / punchTime
            if (k in 0.3f..0.5f) {
                for (w in wolves) {
                    if (w.dead || w.hitCd > 0f) continue
                    val dx = w.x - x
                    val dz = w.z - z
                    if (dx * dx + dz * dz < 1.8f * 1.8f) {
                        w.hitCd = 0.35f
                        onHit(w, Config.PUNCH_DAMAGE, w.x, 0.8f, w.z)
                    }
                }
            }
        }
    }
}
