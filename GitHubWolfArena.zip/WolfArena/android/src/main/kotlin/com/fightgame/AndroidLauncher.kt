package com.fightgame

import android.os.Bundle
import com.badlogic.gdx.backends.android.AndroidApplication
import com.badlogic.gdx.backends.android.AndroidApplicationConfiguration

class AndroidLauncher : AndroidApplication() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val config = AndroidApplicationConfiguration()
        config.useImmersiveMode = true
        config.useWakelock = true
        config.numSamples = 2
        config.r = 8; config.g = 8; config.b = 8; config.a = 8
        config.depth = 24
        initialize(FightGame(), config)
    }
}
