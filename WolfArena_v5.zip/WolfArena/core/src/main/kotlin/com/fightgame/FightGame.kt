package com.fightgame

import com.badlogic.gdx.Application
import com.badlogic.gdx.ApplicationAdapter
import com.badlogic.gdx.Gdx
import com.badlogic.gdx.graphics.Color
import com.badlogic.gdx.graphics.GL20
import com.badlogic.gdx.graphics.PerspectiveCamera
import com.badlogic.gdx.graphics.Pixmap
import com.badlogic.gdx.graphics.Texture
import com.badlogic.gdx.graphics.g2d.BitmapFont
import com.badlogic.gdx.graphics.g2d.GlyphLayout
import com.badlogic.gdx.graphics.g2d.SpriteBatch
import com.badlogic.gdx.graphics.g3d.attributes.ColorAttribute
import com.badlogic.gdx.graphics.glutils.ShapeRenderer
import com.badlogic.gdx.math.MathUtils
import com.badlogic.gdx.math.Vector3
import net.mgsx.gltf.scene3d.attributes.PBRFloatAttribute
import net.mgsx.gltf.scene3d.lights.DirectionalLightEx
import net.mgsx.gltf.scene3d.lights.DirectionalShadowLight
import net.mgsx.gltf.scene3d.scene.SceneManager
import kotlin.math.atan2
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

class FightGame : ApplicationAdapter() {
    private lateinit var sm: SceneManager
    private lateinit var cam: PerspectiveCamera
    private lateinit var sun: DirectionalShadowLight
    private lateinit var arena: Arena
    private lateinit var fx: BloodFx
    private lateinit var controls: Controls
    private lateinit var player: Player
    private lateinit var playerFactory: ActorFactory
    private lateinit var wolfFactory: ActorFactory
    private lateinit var shapes: ShapeRenderer
    private lateinit var sprites: SpriteBatch
    private lateinit var font: BitmapFont
    private lateinit var vignette: Texture
    private val layout = GlyphLayout()
    private val wolves = ArrayList<Wolf>()
    private val rnd = java.util.Random()
    private val tmp = Vector3()

    private var wave = 0
    private var kills = 0
    private var score = 0
    private var waveTimer = 1.5f
    private var hitStop = 0f
    private var shake = 0f
    private var camYaw = 0f
    private var hurtFlash = 0f
    private var gameOverT = 0f
    private var modelsMissing = false
    private var time = 0f

    override fun create() {
        val w = Gdx.graphics.width.toFloat()
        val h = Gdx.graphics.height.toFloat()

        sm = SceneManager(128)
        cam = PerspectiveCamera(58f, w, h)
        cam.near = 0.1f
        cam.far = 120f
        cam.position.set(0f, 4f, -7f)
        cam.lookAt(0f, 1f, 0f)
        cam.update()
        sm.setCamera(cam)

        // ---- Lights: chand ki roshni + shadow + rim ----
        sm.environment.set(ColorAttribute(ColorAttribute.AmbientLight, 0.12f, 0.14f, 0.22f, 1f))
        sun = DirectionalShadowLight(2048, 2048)
        sun.setViewport(30f, 30f, 1f, 50f)
        sun.direction.set(-0.4f, -1f, -0.5f).nor()
        sun.color.set(0.75f, 0.82f, 1f, 1f)
        sun.intensity = 1.8f
        sm.environment.add(sun)
        sm.environment.set(PBRFloatAttribute(PBRFloatAttribute.ShadowBias, 1f / 512f))
        val rim = DirectionalLightEx()
        rim.direction.set(0.5f, -0.3f, 0.8f).nor()
        rim.color.set(1f, 0.6f, 0.45f, 1f)
        rim.intensity = 0.6f
        sm.environment.add(rim)

        // ---- Models ----
        playerFactory = ActorFactory(
            Config.PLAYER_MODEL, Config.PLAYER_HEIGHT, Config.PLAYER_YAW_OFFSET,
            Color(0.25f, 0.45f, 0.95f, 1f), listOf(Config.WALK_ANIM_FILE)
        )
        wolfFactory = ActorFactory(
            Config.WOLF_MODEL, Config.WOLF_HEIGHT, Config.WOLF_YAW_OFFSET,
            Color(0.55f, 0.55f, 0.58f, 1f), emptyList()
        )
        modelsMissing = playerFactory.missing || wolfFactory.missing

        arena = Arena(sm)
        val pa = playerFactory.create()
        sm.addScene(pa.scene)
        player = Player(pa)
        fx = BloodFx(cam)

        controls = Controls()
        controls.resize(Gdx.graphics.width, Gdx.graphics.height)
        Gdx.input.inputProcessor = controls

        shapes = ShapeRenderer()
        sprites = SpriteBatch()
        font = BitmapFont()
        font.region.texture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear)
        vignette = makeVignette()
    }

    private fun makeVignette(): Texture {
        val n = 128
        val pm = Pixmap(n, n, Pixmap.Format.RGBA8888)
        pm.blending = Pixmap.Blending.None
        for (y in 0 until n) for (x in 0 until n) {
            val dx = (x + 0.5f) / n * 2f - 1f
            val dy = (y + 0.5f) / n * 2f - 1f
            val d = sqrt(dx * dx + dy * dy) / 1.414f
            var a = ((d - 0.3f) / 0.7f).coerceIn(0f, 1f)
            a *= a
            pm.drawPixel(x, y, Color.rgba8888(0.65f, 0f, 0f, a))
        }
        val t = Texture(pm)
        t.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear)
        pm.dispose()
        return t
    }

    private fun restart() {
        for (wf in wolves) sm.removeScene(wf.actor.scene)
        wolves.clear()
        fx.clear()
        player.reset()
        wave = 0; kills = 0; score = 0
        waveTimer = 1.5f
        hurtFlash = 0f
        gameOverT = 0f
    }

    private fun startWave(n: Int) {
        wave = n
        val count = min(1 + n, 7)
        for (i in 0 until count) {
            val a = rnd.nextFloat() * MathUtils.PI2
            val rad = Config.ARENA_RADIUS - 2f
            var sx = MathUtils.sin(a) * rad
            var sz = MathUtils.cos(a) * rad
            val ddx = sx - player.x
            val ddz = sz - player.z
            if (ddx * ddx + ddz * ddz < 64f) { sx = -sx; sz = -sz }
            val act = wolfFactory.create()
            sm.addScene(act.scene)
            val hp = 34f + 6f * n
            val sp = min(3.4f + 0.25f * n, 6.2f)
            val dmg = 9f + n
            wolves.add(Wolf(act, sx, sz, hp, sp, dmg))
        }
        waveTimer = 3.5f
    }

    private fun hitWolf(w: Wolf, dmg: Float, hx: Float, hy: Float, hz: Float) {
        val dx = w.x - player.x
        val dz = w.z - player.z
        val d = max(0.001f, sqrt(dx * dx + dz * dz))
        val nx = dx / d
        val nz = dz / d
        val killed = w.takeHit(dmg, nx, nz)
        fx.burst(hx, hy, hz, nx, nz, if (killed) 70 else 28, if (killed) 6f else 4.2f)
        hitStop = if (killed) 0.12f else 0.06f
        shake = max(shake, if (killed) 0.35f else 0.18f)
        if (killed) {
            kills++
            score += 100 + wave * 10
            fx.pool(w.x, w.z)
            fx.burst(w.x, 0.6f, w.z, nx, nz, 50, 5f)
        }
    }

    private fun wolfBite(w: Wolf) {
        val dx = player.x - w.x
        val dz = player.z - w.z
        val d = max(0.001f, sqrt(dx * dx + dz * dz))
        if (player.hurt(w.dmg, dx / d, dz / d)) {
            fx.burst(player.x, 1.2f, player.z, dx / d, dz / d, 24, 3.6f)
            hurtFlash = 1f
            shake = max(shake, 0.4f)
            hitStop = 0.05f
            if (player.isDead) gameOverT = 0f
        }
    }

    private fun update(rawDt: Float) {
        time += rawDt
        controls.poll()
        var dt = rawDt
        if (hitStop > 0f) { hitStop -= rawDt; dt *= 0.06f }

        // Camera ke hisab se joystick -> world direction
        val sy = MathUtils.sin(camYaw)
        val cy = MathUtils.cos(camYaw)
        val wx = sy * controls.my - cy * controls.mx
        val wz = cy * controls.my + sy * controls.mx

        player.update(dt, wx, wz, controls.punchQueued, controls.dashQueued, wolves) { w, dmg, hx, hy, hz ->
            hitWolf(w, dmg, hx, hy, hz)
        }

        val it = wolves.iterator()
        while (it.hasNext()) {
            val wf = it.next()
            wf.update(dt, player, wolves) { b -> wolfBite(b) }
            if (wf.dead && wf.deadT > 8f) {
                sm.removeScene(wf.actor.scene)
                it.remove()
            }
        }

        if (!player.isDead) {
            var alive = 0
            for (wf in wolves) if (!wf.dead) alive++
            if (alive == 0) {
                waveTimer -= dt
                if (waveTimer <= 0f) startWave(wave + 1)
            }
        } else {
            gameOverT += rawDt
            if (gameOverT > 1.2f && controls.tapQueued) restart()
        }

        fx.update(dt)
        arena.update(rawDt)
        hurtFlash = max(0f, hurtFlash - rawDt * 1.6f)
        updateCamera(rawDt)
        controls.endFrame()
    }

    private fun updateCamera(dt: Float) {
        var target: Wolf? = null
        var best = Float.MAX_VALUE
        for (wf in wolves) {
            if (wf.dead) continue
            val dx = wf.x - player.x
            val dz = wf.z - player.z
            val d = dx * dx + dz * dz
            if (d < best) { best = d; target = wf }
        }
        if (target != null && !player.isDead) {
            val desired = atan2(target.x - player.x, target.z - player.z)
            var diff = desired - camYaw
            while (diff > MathUtils.PI) diff -= MathUtils.PI2
            while (diff < -MathUtils.PI) diff += MathUtils.PI2
            camYaw += diff * min(1f, 2.5f * dt)
        }
        val sy = MathUtils.sin(camYaw)
        val cy = MathUtils.cos(camYaw)
        val tx = player.x
        val tz = player.z
        val ty = 1.3f
        val dist = 5.4f
        shake = max(0f, shake - dt * 1.4f)
        val sx = (rnd.nextFloat() - 0.5f) * shake
        val sh = (rnd.nextFloat() - 0.5f) * shake
        cam.position.set(tx - sy * dist + sx, ty + 1.7f + sh, tz - cy * dist + sx)
        cam.up.set(0f, 1f, 0f)
        cam.lookAt(tx + sy * 1.8f, ty - 0.2f, tz + cy * 1.8f)
        cam.update()
        sun.setCenter(tmp.set(player.x, 0f, player.z))
    }

    override fun render() {
        val dt = min(Gdx.graphics.deltaTime, 1f / 20f)
        update(dt)

        Gdx.gl.glDepthMask(true)
        Gdx.gl.glClearColor(0.03f, 0.035f, 0.06f, 1f)
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT or GL20.GL_DEPTH_BUFFER_BIT)

        sm.update(dt)
        sm.renderShadows()
        sm.renderColors()
        fx.render()
        drawHud()
    }

    private fun drawHud() {
        val w = Gdx.graphics.width.toFloat()
        val h = Gdx.graphics.height.toFloat()
        val c = controls
        Gdx.gl.glDisable(GL20.GL_DEPTH_TEST)
        Gdx.gl.glEnable(GL20.GL_BLEND)
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA)

        // Khoon wali screen vignette
        var a = hurtFlash
        if (player.hp < 35f && !player.isDead) a = max(a, 0.25f + 0.15f * MathUtils.sin(time * 6f))
        if (player.isDead) a = 0.7f
        sprites.projectionMatrix.setToOrtho2D(0f, 0f, w, h)
        sprites.begin()
        sprites.setColor(1f, 1f, 1f, a.coerceIn(0f, 1f))
        sprites.draw(vignette, 0f, 0f, w, h)
        sprites.setColor(Color.WHITE)
        sprites.end()

        Gdx.gl.glEnable(GL20.GL_BLEND)
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA)
        shapes.projectionMatrix.setToOrtho2D(0f, 0f, w, h)
        shapes.begin(ShapeRenderer.ShapeType.Filled)
        // HP bar
        val bw = w * 0.34f
        val bh = h * 0.035f
        val bx = w * 0.03f
        val by = h - bh - h * 0.04f
        shapes.setColor(0f, 0f, 0f, 0.6f)
        shapes.rect(bx - 3f, by - 3f, bw + 6f, bh + 6f)
        shapes.setColor(0.35f, 0.05f, 0.05f, 1f)
        shapes.rect(bx, by, bw, bh)
        shapes.setColor(0.85f, 0.1f, 0.1f, 1f)
        shapes.rect(bx, by, bw * (player.hp / player.maxHp).coerceIn(0f, 1f), bh)

        // Touch controls
        if (Gdx.app.type != Application.ApplicationType.Desktop) {
            if (c.joyActive) {
                shapes.setColor(1f, 1f, 1f, 0.12f)
                shapes.circle(c.jcx, c.jcy, c.r * 1.3f, 40)
                shapes.setColor(1f, 1f, 1f, 0.4f)
                shapes.circle(c.jcx + c.jx * c.r * 1.3f, c.jcy + c.jy * c.r * 1.3f, c.r * 0.55f, 32)
            } else {
                shapes.setColor(1f, 1f, 1f, 0.08f)
                shapes.circle(c.r * 1.9f, c.r * 1.9f, c.r * 1.3f, 40)
            }
            shapes.setColor(0.85f, 0.1f, 0.08f, if (c.punchId != -1) 0.85f else 0.5f)
            shapes.circle(c.punchX, c.punchY, c.punchR, 48)
            shapes.setColor(0.2f, 0.45f, 0.9f, if (c.dashId != -1) 0.85f else 0.5f)
            shapes.circle(c.dashX, c.dashY, c.dashR, 40)
        }
        shapes.end()

        // Text
        val sc = h / 450f
        font.data.setScale(sc)
        Gdx.gl.glEnable(GL20.GL_BLEND)
        sprites.begin()
        font.color = Color.WHITE
        center("WAVE $wave", w * 0.5f, h - h * 0.04f)
        font.draw(sprites, "KILLS $kills   SCORE $score", w * 0.03f, by - h * 0.02f)
        if (Gdx.app.type != Application.ApplicationType.Desktop) {
            center("PUNCH", c.punchX, c.punchY + font.capHeight * 0.5f)
            center("DASH", c.dashX, c.dashY + font.capHeight * 0.5f)
        } else {
            font.draw(sprites, "WASD move | SPACE/J punch | SHIFT/K dash", w * 0.03f, h * 0.06f)
        }
        if (player.isDead) {
            font.color = Color(1f, 0.2f, 0.2f, 1f)
            font.data.setScale(sc * 2.2f)
            center("YOU DIED", w * 0.5f, h * 0.6f)
            font.data.setScale(sc)
            font.color = Color.WHITE
            if (gameOverT > 1.2f) center("Tap to restart", w * 0.5f, h * 0.45f)
        } else if (wolves.none { !it.dead } && wave > 0) {
            center("Next wave incoming...", w * 0.5f, h * 0.7f)
        }
        if (Config.DEBUG) {
            font.color = Color.CYAN
            font.data.setScale(sc * 0.55f)
            font.draw(sprites, Models.info.take(3).joinToString("  |  "), w * 0.03f, h * 0.05f)
        }
        if (modelsMissing) {
            font.color = Color.YELLOW
            font.data.setScale(sc * 0.7f)
            val msg = if (Models.errors.isEmpty()) "Models missing" else Models.errors.joinToString("  |  ")
            center(msg, w * 0.5f, h * 0.88f)
        }
        sprites.end()
        Gdx.gl.glEnable(GL20.GL_DEPTH_TEST)
    }

    private fun center(text: String, x: Float, y: Float) {
        layout.setText(font, text)
        font.draw(sprites, layout, x - layout.width / 2f, y)
    }

    override fun resize(width: Int, height: Int) {
        cam.viewportWidth = width.toFloat()
        cam.viewportHeight = height.toFloat()
        cam.update()
        controls.resize(width, height)
    }

    override fun dispose() {
        sm.dispose()
        arena.dispose()
        fx.dispose()
        shapes.dispose()
        sprites.dispose()
        font.dispose()
        vignette.dispose()
    }
}
